﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpellingGame
{
    class WordWSpelling : Word
    {
        String[] wrong;

        String Wrong1 { get { return wrong[0]; } set { wrong[0] = value; } }
        String Wrong2{ get { return wrong[1]; } set { wrong[1] = value; } }
        String Wrong3 { get { return wrong[2]; } set { wrong[2] = value; } }
        public WordWSpelling(int number, String word, String voice,String wrong1,String wrong2,String wrong3) : base(number,word,voice)
        {
            wrong = new string[3];
            Wrong1 = wrong1;
            Wrong2 = wrong2;
            Wrong3 = wrong3;
        }
    }
}
