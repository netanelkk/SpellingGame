﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpellingGame
{
    class Word : IComparable<Word>
    {
        int number;
        String wordvalue;
        String voice;
        public int Number { get { return number; } set { number = value; } }
        public String WordValue { get { return wordvalue; } set { wordvalue = value; } }
        public String Voice { get { return voice; } set { voice = value; } }
        public Word(int number, String word, String voice)
        {
            Number = number;
            WordValue = word;
            Voice = voice;
        }

        public int CompareTo(Word other)
        {
            if(other.WordValue.Equals(WordValue))
            {
                return 1;
            }
            return 0;
        }
    }
}
